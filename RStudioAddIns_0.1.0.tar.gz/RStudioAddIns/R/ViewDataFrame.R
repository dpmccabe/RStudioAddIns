#' ViewDataFrame
#'
#' @param text - Data Frame
#'
#' @return
#' @export
#'
#' @examples
ViewDataFrame <- function(text) {

  if (!is.data.frame(eval(text))) {
    stop("Must select data frame ...")
  }

  View(x = eval(text),
       title = "ViewDataFrame")

}
